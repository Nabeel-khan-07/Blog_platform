from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, authenticate
from django.core.mail import send_mail
from django.contrib import messages
from django.contrib.auth import get_user_model
import pyotp

from .models import Profile

User = get_user_model()

def register(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')

       
        user = User.objects.create_user(username=username, email=email, password=password)

       
        Profile.objects.create(user=user)

       
        otp_secret_key = pyotp.random_base32()
        user.profile.otp_secret_key = otp_secret_key
        user.profile.save()

        totp = pyotp.TOTP(otp_secret_key)
        otp = totp.now()

        
        user.profile.otp = otp
        user.profile.save()

       
        send_mail(
            'OTP for Registration',
            f'Your OTP is: {otp}',
            'from@example.com',
            [user.email],
            fail_silently=False,
        )

        messages.success(request, 'Registration successful. Please check your email for the OTP.')
        return render(request, 'registration_success.html') 

    return render(request, 'registration.html')  

@login_required
def generate_otp(request):
    user = request.user

    otp_secret_key = pyotp.random_base32()
    user.profile.otp_secret_key = otp_secret_key
    user.profile.save()

    
    totp = pyotp.TOTP(otp_secret_key)
    otp = totp.now()

    
    user.profile.otp = otp
    user.profile.save()

 
    send_mail(
        'OTP for Login',
        f'Your OTP is: {otp}',
        'from@example.com',
        [user.email],
        fail_silently=False,
    )

    return render(request, 'otp_sent.html')  

@login_required
def validate_otp(request):
    if request.method == 'POST':
        entered_otp = request.POST.get('otp')
        user = request.user

        
        saved_otp = user.profile.otp
        otp_secret_key = user.profile.otp_secret_key

      
        totp = pyotp.TOTP(otp_secret_key)
        if totp.verify(entered_otp):
           
            authenticated_user = authenticate(request, username=user.username, password=user.password)
            login(request, authenticated_user)
            messages.success(request, 'OTP verification successful. You are now logged in.')
        else:
            
            messages.error(request, 'Invalid OTP. Please try again.')

    return redirect('home') 
