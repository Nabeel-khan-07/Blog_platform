from django.urls import path
from .views import register, generate_otp, validate_otp

urlpatterns = [
    path('register/', register, name='register'),
    path('generate-otp/', generate_otp, name='generate_otp'),
    path('validate-otp/', validate_otp, name='validate_otp'),
]
