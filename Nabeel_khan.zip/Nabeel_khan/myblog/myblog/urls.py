from django.contrib import admin
from django.urls import path, include
from blog.views import post_list, post_detail
from authentication.views import register, generate_otp, validate_otp
from api.views import PostListCreateAPIView, CommentListCreateAPIView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('register/', register, name='register'),
    path('generate-otp/', generate_otp, name='generate_otp'),
    path('validate-otp/', validate_otp, name='validate_otp'),
    path('posts/', post_list, name='post_list'),
    path('posts/<int:pk>/', post_detail, name='post_detail'),
    path('api/posts/', PostListCreateAPIView.as_view(), name='api_post_list_create'),
    path('api/comments/', CommentListCreateAPIView.as_view(), name='api_comment_list_create'),
]

